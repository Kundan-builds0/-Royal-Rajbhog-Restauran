import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { and, desc, eq, ilike, inArray, or, sql } from "drizzle-orm";
import { getAuth } from "@clerk/express";
import {
  CreateMenuItemBody,
  CreateOrderBody,
  CreateReviewBody,
  GetOrderParams,
  ListMenuQueryParams,
  ListOrdersQueryParams,
  UpdateMenuItemBody,
  UpdateMenuItemParams,
  UpdateOrderStatusBody,
  UpdateOrderStatusParams,
} from "@workspace/api-zod";
import {
  db,
  menuItemsTable,
  ordersTable,
  reviewsTable,
  type MenuItem,
} from "@workspace/db";

const router: IRouter = Router();

function requireStaff(req: Request, res: Response, next: NextFunction) {
  const { isAuthenticated, sessionClaims } = getAuth(req);
  const claims = (sessionClaims ?? {}) as {
    metadata?: { role?: string };
    publicMetadata?: { role?: string };
  };
  const role = claims.metadata?.role ?? claims.publicMetadata?.role;
  if (!isAuthenticated) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  if (role !== "admin" && role !== "staff") {
    res.status(403).json({ error: "Staff access required" });
    return;
  }
  next();
}
const categories = [
  "Starters",
  "Soups",
  "Main Course",
  "Indian Breads",
  "Rice & Biryani",
  "Chinese",
  "Snacks",
  "Beverages",
  "Desserts",
  "Special / Recommended",
];

const seedMenu = [
  {
    name: "Paneer Tikka",
    hindiName: "पनीर टिक्का",
    description: "Char-grilled cottage cheese, peppers and onion with royal spices.",
    ingredients: "Paneer, bell peppers, onion, yoghurt, tandoori masala",
    price: 240,
    category: "Starters",
    imageUrl:
      "https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=900&q=85",
    isVegetarian: true,
    isPopular: true,
    isRecommended: true,
  },
  {
    name: "Dal Rajbhog",
    hindiName: "दाल राजभोग",
    description: "Slow-cooked black lentils finished with butter and cream.",
    ingredients: "Black lentils, tomato, butter, cream, cumin",
    price: 220,
    category: "Main Course",
    imageUrl:
      "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=900&q=85",
    isVegetarian: true,
    isPopular: true,
    isRecommended: true,
  },
  {
    name: "Royal Veg Biryani",
    hindiName: "रॉयल वेज बिरयानी",
    description: "Fragrant basmati rice layered with garden vegetables and saffron.",
    ingredients: "Basmati rice, vegetables, saffron, fried onion, mint",
    price: 280,
    category: "Rice & Biryani",
    imageUrl:
      "https://images.unsplash.com/photo-1563379091339-03246963d96c?auto=format&fit=crop&w=900&q=85",
    isVegetarian: true,
    isPopular: true,
    isRecommended: true,
  },
  {
    name: "Butter Naan",
    hindiName: "बटर नान",
    description: "Soft tandoor-baked naan brushed with golden butter.",
    ingredients: "Refined flour, yoghurt, butter, coriander",
    price: 55,
    category: "Indian Breads",
    imageUrl:
      "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=85",
    isVegetarian: true,
    isPopular: false,
    isRecommended: false,
  },
  {
    name: "Veg Hakka Noodles",
    hindiName: "वेज हक्का नूडल्स",
    description: "Wok-tossed noodles with crisp vegetables and a smoky finish.",
    ingredients: "Noodles, cabbage, carrot, capsicum, soy",
    price: 190,
    category: "Chinese",
    imageUrl:
      "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=900&q=85",
    isVegetarian: true,
    isPopular: false,
    isRecommended: true,
  },
  {
    name: "Matka Kulfi",
    hindiName: "मटका कुल्फी",
    description: "Silky saffron kulfi served in a traditional earthen matka.",
    ingredients: "Milk, khoya, saffron, pistachio, cardamom",
    price: 140,
    category: "Desserts",
    imageUrl:
      "https://images.unsplash.com/photo-1582716401301-b2407dc7563d?auto=format&fit=crop&w=900&q=85",
    isVegetarian: true,
    isPopular: true,
    isRecommended: true,
  },
  {
    name: "Masala Chaas",
    hindiName: "मसाला छाछ",
    description: "Chilled spiced buttermilk with roasted cumin and mint.",
    ingredients: "Buttermilk, cumin, mint, coriander, rock salt",
    price: 80,
    category: "Beverages",
    imageUrl:
      "https://images.unsplash.com/photo-1623065422902-30a2d299bbe4?auto=format&fit=crop&w=900&q=85",
    isVegetarian: true,
    isPopular: false,
    isRecommended: false,
  },
];

const seedReviews = [
  {
    customerName: "Aarav S.",
    rating: 5,
    comment:
      "Excellent food, warm ambiance, friendly staff, quick service, and great value.",
  },
  {
    customerName: "Meera K.",
    rating: 5,
    comment: "Very good food along with timely service.",
  },
  {
    customerName: "Rohan P.",
    rating: 5,
    comment: "Very tasty and yummy 😋",
  },
];

let seedPromise: Promise<void> | undefined;

async function ensureSeeded() {
  if (!seedPromise) {
    seedPromise = (async () => {
      const menuCount = await db
        .select({ count: sql<number>`count(*)` })
        .from(menuItemsTable);
      if (Number(menuCount[0]?.count ?? 0) === 0) {
        await db
          .insert(menuItemsTable)
          .values(seedMenu.map((item) => ({ ...item, price: String(item.price) })));
      }
      const reviewCount = await db
        .select({ count: sql<number>`count(*)` })
        .from(reviewsTable);
      if (Number(reviewCount[0]?.count ?? 0) === 0) {
        await db.insert(reviewsTable).values(seedReviews);
      }
    })();
  }
  await seedPromise;
}

function toMenuItem(item: MenuItem) {
  return {
    id: item.id,
    name: item.name,
    hindiName: item.hindiName,
    description: item.description,
    ingredients: item.ingredients,
    price: Number(item.price),
    category: item.category,
    imageUrl: item.imageUrl,
    isVegetarian: item.isVegetarian,
    isAvailable: item.isAvailable,
    isPopular: item.isPopular,
    isRecommended: item.isRecommended,
  };
}

function toOrder(order: typeof ordersTable.$inferSelect) {
  return {
    ...order,
    subtotal: Number(order.subtotal),
    deliveryCharge: Number(order.deliveryCharge),
    tax: Number(order.tax),
    total: Number(order.total),
    items: order.items,
    createdAt: order.createdAt,
  };
}

router.get("/menu", async (req, res) => {
  try {
    await ensureSeeded();
    const query = ListMenuQueryParams.parse(req.query);
    const filters = [];
    if (query.category) filters.push(eq(menuItemsTable.category, query.category));
    if (query.availableOnly) filters.push(eq(menuItemsTable.isAvailable, true));
    if (query.search) {
      const term = `%${query.search}%`;
      filters.push(
        or(
          ilike(menuItemsTable.name, term),
          ilike(menuItemsTable.hindiName, term),
          ilike(menuItemsTable.category, term),
          ilike(menuItemsTable.ingredients, term),
        ),
      );
    }
    const result = await db
      .select()
      .from(menuItemsTable)
      .where(filters.length ? and(...filters) : undefined)
      .orderBy(desc(menuItemsTable.isRecommended), menuItemsTable.name);
    res.json(result.map(toMenuItem));
  } catch (error) {
    req.log.error({ err: error }, "Failed to list menu");
    res.status(500).json({ error: "Unable to load menu" });
  }
});

router.post("/menu", requireStaff, async (req, res) => {
  try {
    const body = CreateMenuItemBody.parse(req.body);
    const [created] = await db
      .insert(menuItemsTable)
      .values({
        ...body,
        ingredients: body.ingredients ?? "",
        isAvailable: body.isAvailable ?? true,
        isPopular: body.isPopular ?? false,
        isRecommended: body.isRecommended ?? false,
        price: String(body.price),
      })
      .returning();
    res.status(201).json(toMenuItem(created));
  } catch (error) {
    req.log.error({ err: error }, "Failed to create menu item");
    res.status(400).json({ error: "Unable to create menu item" });
  }
});

router.patch("/menu/:id", requireStaff, async (req, res) => {
  try {
    const { id } = UpdateMenuItemParams.parse(req.params);
    const body = UpdateMenuItemBody.parse(req.body);
    const [updated] = await db
      .update(menuItemsTable)
      .set({
        ...body,
        price: body.price === undefined ? undefined : String(body.price),
      })
      .where(eq(menuItemsTable.id, id))
      .returning();
    if (!updated) {
      res.status(404).json({ error: "Menu item not found" });
      return;
    }
    res.json(toMenuItem(updated));
    return;
  } catch (error) {
    req.log.error({ err: error }, "Failed to update menu item");
    res.status(400).json({ error: "Unable to update menu item" });
    return;
  }
});

router.delete("/menu/:id", requireStaff, async (req, res) => {
  try {
    const { id } = UpdateMenuItemParams.parse(req.params);
    await db.delete(menuItemsTable).where(eq(menuItemsTable.id, id));
    res.status(204).send();
  } catch (error) {
    req.log.error({ err: error }, "Failed to delete menu item");
    res.status(400).json({ error: "Unable to delete menu item" });
  }
});

router.get("/categories", async (_req, res) => {
  await ensureSeeded();
  const rows = await db
    .select({
      name: menuItemsTable.category,
      count: sql<number>`count(*)`,
    })
    .from(menuItemsTable)
    .groupBy(menuItemsTable.category);
  const counts = new Map(rows.map((row) => [row.name, Number(row.count)]));
  res.json(
    categories.map((name, index) => ({
      id: index + 1,
      name,
      count: counts.get(name) ?? 0,
    })),
  );
});

router.get("/orders", async (req, res) => {
  const query = ListOrdersQueryParams.parse(req.query);
  const filters = [];
  if (query.customerPhone) filters.push(eq(ordersTable.phone, query.customerPhone));
  if (query.status) filters.push(eq(ordersTable.status, query.status));
  const orders = await db
    .select()
    .from(ordersTable)
    .where(filters.length ? and(...filters) : undefined)
    .orderBy(desc(ordersTable.createdAt));
  res.json(orders.map(toOrder));
});

router.post("/orders", async (req, res) => {
  try {
    const body = CreateOrderBody.parse(req.body);
    if (body.orderType === "delivery" && !body.address?.trim()) {
      res.status(400).json({ error: "Delivery address is required" });
      return;
    }
    const ids = body.items.map((item) => item.menuItemId);
    const menu = await db
      .select()
      .from(menuItemsTable)
      .where(inArray(menuItemsTable.id, ids));
    const byId = new Map(menu.map((item) => [item.id, item]));
    const snapshot = body.items.map((line) => {
      const item = byId.get(line.menuItemId);
      if (!item || !item.isAvailable) throw new Error("One or more dishes are unavailable");
      const unitPrice = Number(item.price);
      return {
        menuItemId: item.id,
        name: item.name,
        quantity: line.quantity,
        unitPrice,
        subtotal: unitPrice * line.quantity,
        imageUrl: item.imageUrl,
      };
    });
    const subtotal = snapshot.reduce((sum, item) => sum + item.subtotal, 0);
    const deliveryCharge = body.orderType === "delivery" ? 40 : 0;
    const tax = Math.round(subtotal * 0.05 * 100) / 100;
    const total = subtotal + deliveryCharge + tax;
    const orderNumber = `RR${Date.now().toString().slice(-7)}`;
    const [created] = await db
      .insert(ordersTable)
      .values({
        orderNumber,
        customerName: body.customerName,
        phone: body.phone,
        email: body.email ?? "",
        address: body.address ?? "",
        landmark: body.landmark ?? "",
        instructions: body.instructions ?? "",
        orderType: body.orderType,
        paymentMethod: body.paymentMethod,
        paymentStatus: "pending",
        status: "placed",
        items: snapshot,
        subtotal: String(subtotal),
        deliveryCharge: String(deliveryCharge),
        tax: String(tax),
        total: String(total),
      })
      .returning();
    res.status(201).json(toOrder(created));
    return;
  } catch (error) {
    req.log.error({ err: error }, "Failed to create order");
    res.status(400).json({ error: "Unable to place order" });
    return;
  }
});

router.get("/orders/:id", async (req, res) => {
  try {
    const { id } = GetOrderParams.parse(req.params);
    const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, id));
    if (!order) {
      res.status(404).json({ error: "Order not found" });
      return;
    }
    res.json(toOrder(order));
    return;
  } catch (error) {
    req.log.error({ err: error }, "Failed to get order");
    res.status(400).json({ error: "Unable to load order" });
    return;
  }
});

router.patch("/orders/:id/status", requireStaff, async (req, res) => {
  try {
    const { id } = UpdateOrderStatusParams.parse(req.params);
    const { status } = UpdateOrderStatusBody.parse(req.body);
    const [updated] = await db
      .update(ordersTable)
      .set({ status })
      .where(eq(ordersTable.id, id))
      .returning();
    if (!updated) {
      res.status(404).json({ error: "Order not found" });
      return;
    }
    res.json(toOrder(updated));
    return;
  } catch (error) {
    req.log.error({ err: error }, "Failed to update order status");
    res.status(400).json({ error: "Unable to update order status" });
    return;
  }
});

router.get("/reviews", async (_req, res) => {
  await ensureSeeded();
  const reviews = await db.select().from(reviewsTable).orderBy(desc(reviewsTable.createdAt));
  res.json(reviews);
});

router.post("/reviews", async (req, res) => {
  try {
    const body = CreateReviewBody.parse(req.body);
    const [created] = await db.insert(reviewsTable).values(body).returning();
    res.status(201).json(created);
  } catch (error) {
    req.log.error({ err: error }, "Failed to create review");
    res.status(400).json({ error: "Unable to submit review" });
  }
});

router.get("/dashboard/summary", requireStaff, async (_req, res) => {
  const orders = await db.select().from(ordersTable);
  const today = new Date();
  const todayOrders = orders.filter((order) => {
    const created = new Date(order.createdAt);
    return created.toDateString() === today.toDateString();
  });
  const todaySales = todayOrders.reduce((sum, order) => sum + Number(order.total), 0);
  const itemCounts = new Map<string, number>();
  for (const order of orders) {
    for (const item of order.items) {
      itemCounts.set(item.name, (itemCounts.get(item.name) ?? 0) + item.quantity);
    }
  }
  const popularItems = [...itemCounts.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([name, count]) => ({ name, orders: count }));
  const weeklySales = Array.from({ length: 7 }, (_, index) => {
    const day = new Date();
    day.setDate(day.getDate() - (6 - index));
    const amount = orders
      .filter((order) => new Date(order.createdAt).toDateString() === day.toDateString())
      .reduce((sum, order) => sum + Number(order.total), 0);
    return {
      day: day.toLocaleDateString("en-IN", { weekday: "short" }),
      amount,
    };
  });
  res.json({
    todaySales,
    todayOrders: todayOrders.length,
    pendingOrders: orders.filter((order) =>
      ["placed", "confirmed", "preparing", "ready", "out_for_delivery"].includes(order.status),
    ).length,
    averageOrderValue: orders.length
      ? orders.reduce((sum, order) => sum + Number(order.total), 0) / orders.length
      : 0,
    popularItems,
    weeklySales,
  });
});

router.get("/dashboard/orders", requireStaff, async (_req, res) => {
  const orders = await db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt)).limit(20);
  res.json(orders.map(toOrder));
});

export default router;